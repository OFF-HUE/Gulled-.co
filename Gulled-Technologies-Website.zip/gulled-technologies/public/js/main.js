const menuButton = document.querySelector(".menu-toggle");
const nav = document.querySelector(".nav-links");

menuButton.addEventListener("click", () => {
  const isOpen = nav.classList.toggle("open");
  menuButton.setAttribute("aria-expanded", String(isOpen));
});

document.querySelectorAll(".nav-links a").forEach(link => {
  link.addEventListener("click", () => {
    nav.classList.remove("open");
    menuButton.setAttribute("aria-expanded", "false");
  });
});

document.getElementById("year").textContent = new Date().getFullYear();

async function submitForm(form, endpoint) {
  const status = form.querySelector(".form-status");
  const button = form.querySelector('button[type="submit"]');
  const originalText = button.innerHTML;
  status.textContent = "";
  button.disabled = true;
  button.textContent = "Sending...";

  const data = Object.fromEntries(new FormData(form).entries());
  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.message || "Something went wrong.");
    status.textContent = result.message;
    form.reset();
  } catch (error) {
    status.textContent = error.message || "Unable to send. Please try again.";
    status.style.color = "#b54747";
  } finally {
    button.disabled = false;
    button.innerHTML = originalText;
  }
}

document.getElementById("contact-form").addEventListener("submit", event => {
  event.preventDefault();
  submitForm(event.currentTarget, "/api/contact");
});

document.getElementById("career-form").addEventListener("submit", event => {
  event.preventDefault();
  submitForm(event.currentTarget, "/api/careers");
});
