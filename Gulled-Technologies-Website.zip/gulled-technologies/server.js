require("dotenv").config();

const express = require("express");
const helmet = require("helmet");
const path = require("path");
const mongoose = require("mongoose");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(helmet({
  contentSecurityPolicy: false
}));
app.use(express.json({ limit: "30kb" }));
app.use(express.urlencoded({ extended: true, limit: "30kb" }));
app.use(express.static(path.join(__dirname, "public")));

const messageSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 100 },
  email: { type: String, required: true, trim: true, lowercase: true, maxlength: 160 },
  company: { type: String, trim: true, maxlength: 120 },
  service: { type: String, trim: true, maxlength: 100 },
  message: { type: String, required: true, trim: true, maxlength: 3000 },
  createdAt: { type: Date, default: Date.now }
});

const applicationSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 100 },
  email: { type: String, required: true, trim: true, lowercase: true, maxlength: 160 },
  role: { type: String, required: true, trim: true, maxlength: 100 },
  portfolio: { type: String, trim: true, maxlength: 500 },
  note: { type: String, trim: true, maxlength: 2000 },
  createdAt: { type: Date, default: Date.now }
});

const Message = mongoose.model("Message", messageSchema);
const Application = mongoose.model("Application", applicationSchema);

function validEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email || ""));
}

app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    service: "Gulled Technologies website",
    database: mongoose.connection.readyState === 1 ? "connected" : "not connected"
  });
});

app.post("/api/contact", async (req, res) => {
  try {
    const { name, email, company = "", service = "", message } = req.body;
    if (!name || !validEmail(email) || !message) {
      return res.status(400).json({ message: "Please provide your name, a valid email, and a message." });
    }
    if (mongoose.connection.readyState !== 1) {
      return res.status(503).json({ message: "The contact service is temporarily unavailable. Please try again later." });
    }
    await Message.create({ name, email, company, service, message });
    res.status(201).json({ message: "Thank you. Your message has been received." });
  } catch (error) {
    console.error("Contact submission error:", error.message);
    res.status(500).json({ message: "We could not send your message. Please try again." });
  }
});

app.post("/api/careers", async (req, res) => {
  try {
    const { name, email, role, portfolio = "", note = "" } = req.body;
    if (!name || !validEmail(email) || !role) {
      return res.status(400).json({ message: "Please provide your name, a valid email, and the role you are interested in." });
    }
    if (mongoose.connection.readyState !== 1) {
      return res.status(503).json({ message: "The careers service is temporarily unavailable. Please try again later." });
    }
    await Application.create({ name, email, role, portfolio, note });
    res.status(201).json({ message: "Thank you for your interest. Your application has been received." });
  } catch (error) {
    console.error("Career submission error:", error.message);
    res.status(500).json({ message: "We could not submit your application. Please try again." });
  }
});

app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

async function start() {
  if (process.env.MONGODB_URI) {
    try {
      await mongoose.connect(process.env.MONGODB_URI);
      console.log("MongoDB connected.");
    } catch (error) {
      console.error("MongoDB connection failed:", error.message);
      console.error("The website will still start, but forms need MongoDB to save submissions.");
    }
  } else {
    console.warn("MONGODB_URI is not set. Website pages work; form submissions are disabled.");
  }

  app.listen(PORT, () => console.log(`Gulled Technologies is running at http://localhost:${PORT}`));
}

start();
