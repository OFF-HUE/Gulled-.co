# Gulled Technologies Website

A responsive company website with an Express backend and MongoDB-backed contact and careers forms.

## Requirements
- Node.js 18 or newer
- npm
- MongoDB local installation or a MongoDB Atlas connection string

## 1. Install
```bash
npm install
```

## 2. Configure the database
Copy `.env.example` to `.env`, then set `MONGODB_URI`.

Windows PowerShell:
```powershell
Copy-Item .env.example .env
```

macOS / Linux:
```bash
cp .env.example .env
```

For a local MongoDB installation, the example URI can be used:
`mongodb://127.0.0.1:27017/gulled_technologies`

For MongoDB Atlas, replace it with your own connection string. Never publish your `.env` file.

## 3. Start the website
```bash
npm start
```
Open http://localhost:3000

For development with auto-restart:
```bash
npm run dev
```

## Included features
- Responsive English company website
- Home, About, Services, Our Approach, Careers, and Contact sections
- Mobile navigation
- Contact form saved to MongoDB
- Careers interest form saved to MongoDB
- Basic server security headers and input limits
- Health endpoint: `/api/health`

## Important before publishing
1. Confirm the company name and any legal registration requirements in your jurisdiction.
2. Add real company contact details only after they are available.
3. Replace the sample GT mark if you approve a different final logo.
4. Configure MongoDB securely and use environment variables on the hosting provider.
5. Deploy the Node.js server to a host that supports Node.js. GitHub Pages alone cannot run this backend.
6. Add privacy, data-retention, and terms pages before collecting real customer or applicant information.
7. Add HTTPS and backups in production.

## Project structure
```text
gulled-technologies/
├── public/
│   ├── assets/gt-mark.svg
│   ├── css/styles.css
│   ├── js/main.js
│   └── index.html
├── .env.example
├── .gitignore
├── package.json
├── server.js
└── README.md
```

This is a complete starter website project. It does not include an admin dashboard, payment processing, employee accounts, or a deployed public domain.
